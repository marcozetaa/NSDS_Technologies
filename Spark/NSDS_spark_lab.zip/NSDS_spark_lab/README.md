# Apache Spark Lab

Apache Spark: lab exercises for the NSDS course at Politecnico di Milano
